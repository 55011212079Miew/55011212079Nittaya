//
//  Calculator.swift
//  Exam1
//
//  Created by student on 10/10/14.
//  Copyright (c) 2014 nittaya. All rights reserved.
//

import Foundation
class Calculator{
   
    var name : String
    var volume :Double
    var price :Double
    var total : Double
}